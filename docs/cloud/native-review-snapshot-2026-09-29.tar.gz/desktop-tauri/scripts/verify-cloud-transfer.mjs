import assert from 'node:assert/strict';
import { createRequire } from 'node:module';
import { fileURLToPath } from 'node:url';
import { chromium } from 'playwright-core';

const require = createRequire(new URL('../../mobile/package.json', import.meta.url));
const { build } = require('esbuild');
const root = fileURLToPath(new URL('../', import.meta.url));
const bundle = await build({
  absWorkingDir: root, bundle: true, write: false, format: 'iife', jsx: 'automatic',
  stdin: { loader: 'tsx', resolveDir: root, contents: `
    import {createRoot} from 'react-dom/client';
    import {SettingsPhoneTransfer} from './src/components/settings/SettingsPhoneTransfer';
    window.calls=[];
    createRoot(document.getElementById('root')).render(<SettingsPhoneTransfer error="host-transfer-required: conflict"/>);
  ` },
  plugins: [{ name: 'synthetic-cloud', setup(build) {
    build.onLoad({ filter: /src\/ipc\/phone\.ts$/ }, () => ({ loader: 'js', contents: `
      export async function phoneRemoteTransferContext() {
        window.calls.push({type:'review'});
        return {accountScope:'account-a',email:'owner@example.test',hostId:'host-a'};
      }
      export async function phoneRemoteTransfer(context) {
        window.calls.push({type:'transfer',context});
        if(window.rejectTransfer) throw Error('The account or computer changed. Review the transfer again.');
        return {remote:{leg:{state:'connecting'}}};
      }
    ` }));
    build.onLoad({ filter: /src\/state\/phoneStore\.ts$/ }, () => ({ loader: 'js', contents:
      'export const usePhoneStore={setState(value){window.updated=value}};' }));
  } }],
});
const browser = await chromium.launch({channel:'chrome',headless:true});
try {
  const page = await browser.newPage();
  await page.setContent('<div id="root"></div>');
  await page.addScriptTag({content:bundle.outputFiles[0].text});
  await page.getByRole('button', {name:'Review transfer'}).click();
  await page.getByText('Move this computer to owner@example.test?').waitFor();
  assert.equal(await page.getByRole('button', {name:'Cancel'}).getAttribute('class'),
    await page.getByRole('button', {name:'Move computer',exact:true}).getAttribute('class'));
  await page.getByRole('button', {name:'Cancel'}).click();
  assert.deepEqual(await page.evaluate(()=>window.calls), [{type:'review'}]);
  await page.getByRole('button', {name:'Review transfer'}).click();
  await page.evaluate(()=>{window.rejectTransfer=true});
  await page.getByRole('button', {name:'Move computer',exact:true}).click();
  await page.getByRole('alert').waitFor();
  assert.match(await page.getByRole('alert').innerText(), /account or computer changed/);
  assert.deepEqual(await page.evaluate(()=>window.calls.filter(c=>c.type==='transfer')), [
    {type:'transfer',context:{accountScope:'account-a',email:'owner@example.test',hostId:'host-a'}},
  ]);
  await page.getByRole('button', {name:'Cancel'}).click();
  await page.getByRole('button', {name:'Review transfer'}).click();
  await page.evaluate(()=>{window.rejectTransfer=false});
  await page.getByRole('button', {name:'Move computer',exact:true}).click();
  await page.waitForFunction(()=>window.updated?.status?.remote?.leg?.state==='connecting');
  console.log('PASS: review/cancel sends no transfer; account+host binding; balanced consent; stale rejection; success. Synthetic IPC only.');
} finally { await browser.close(); }
