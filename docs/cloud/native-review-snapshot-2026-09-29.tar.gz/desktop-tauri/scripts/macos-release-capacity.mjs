/** Capacity is checked once for the entire batch before the first write.
 * A missing remote command, unreachable service or insufficient headroom
 * throws from railway: never fall through to an upload on uncertainty. */
export function uploadWithCapacity(plans, { apply, send, service, railway, upload }) {
  if (!apply) return;
  if (typeof send !== 'boolean') throw new Error('Choose upload or verification explicitly.');
  if (send) {
    let incoming = 0;
    for (const { entry } of plans) {
      if (!Number.isSafeInteger(entry.size) || entry.size <= 0
        || !Number.isSafeInteger(incoming + entry.size)) {
        throw new Error('Release artifacts need valid bounded byte counts before upload.');
      }
      incoming += entry.size;
    }
    if (!incoming) throw new Error('No release artifacts to upload.');
    railway(['ssh', ...service, '--', 'php', 'artisan', 'vibyra:release-capacity',
      `--incoming-bytes=${incoming}`]);
  }
  for (const plan of plans) upload(plan, { send });
}
