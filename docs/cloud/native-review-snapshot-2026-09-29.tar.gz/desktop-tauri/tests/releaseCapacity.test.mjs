import assert from 'node:assert/strict';
import test from 'node:test';
import { uploadWithCapacity } from '../scripts/macos-release-capacity.mjs';

const plans = [{entry:{size:100,name:'arm'}},{entry:{size:250,name:'intel'}}];
const service = ['--service','Vibyra','--environment','production'];
const setup = (changes = {}) => {
  const calls = [];
  return {calls, options:{apply:true,send:true,service,
    railway: args=>calls.push(['preflight',args]),
    upload:(plan,{send})=>calls.push(['upload',plan.entry.name,send]), ...changes}};
};
test('one whole-batch capacity preflight precedes both architecture uploads', () => {
  const {calls,options}=setup(); uploadWithCapacity(plans,options);
  assert.deepEqual(calls,[
    ['preflight',['ssh',...service,'--','php','artisan','vibyra:release-capacity','--incoming-bytes=350']],
    ['upload','arm',true],['upload','intel',true],
  ]);
});
for (const reason of ['Command does not exist','Insufficient release headroom','SSH unavailable']) {
  test(`preflight fails closed: ${reason}`, () => {
    const {calls,options}=setup({railway:()=>{throw Error(reason)}});
    assert.throws(()=>uploadWithCapacity(plans,options),{message:reason});
    assert.deepEqual(calls,[]);
  });
}
test('dry run performs no remote reads or writes', () => {
  const {calls,options}=setup({apply:false}); uploadWithCapacity(plans,options); assert.deepEqual(calls,[]);
});
test('skip-upload keeps verification without reserving bytes already on disk', () => {
  const {calls,options}=setup({send:false}); uploadWithCapacity(plans,options);
  assert.deepEqual(calls,[['upload','arm',false],['upload','intel',false]]);
});
test('an omitted upload mode cannot bypass the preflight and inherit upload defaults', () => {
  const {calls,options}=setup({send:undefined});
  assert.throws(()=>uploadWithCapacity(plans,options), /explicitly/); assert.deepEqual(calls,[]);
});
test('invalid sizes and unsafe sums fail before any remote action', () => {
  for (const batch of [[],[{entry:{size:-1}}],[{entry:{size:NaN}}],
    [{entry:{size:Number.MAX_SAFE_INTEGER}},{entry:{size:1}}]]) {
    const {calls,options}=setup(); assert.throws(()=>uploadWithCapacity(batch,options)); assert.deepEqual(calls,[]);
  }
});
